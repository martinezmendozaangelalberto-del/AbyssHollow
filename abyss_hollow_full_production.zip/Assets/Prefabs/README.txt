Prefab setup (do in Unity Editor):
- Player prefab: CharacterController, PhotonView, PlayerController, Camera child (disabled for remote)
- Killer prefab: CharacterController, PhotonView, KillerController
- Weapon prefabs: mesh + WeaponController
- Car prefab: CarEscape + collider
- Boat prefab: BoatEscape + collider
DemoScene: place spawn points, assign MatchManager references, add CarPartSpawner and Weapon spawners, add a few BearTrap prefabs.
