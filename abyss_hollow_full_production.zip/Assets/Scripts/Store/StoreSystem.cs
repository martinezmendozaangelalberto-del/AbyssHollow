using UnityEngine; public class StoreSystem : MonoBehaviour { public void BuySkin(string id){ Debug.Log("Buy skin: " + id); } public void BuyKiller(string id){ Debug.Log("Buy killer: " + id); } }
