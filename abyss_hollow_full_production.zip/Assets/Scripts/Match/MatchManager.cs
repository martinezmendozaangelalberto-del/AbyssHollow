using UnityEngine;
using Photon.Pun;
public class MatchManager : MonoBehaviourPun {
    public GameObject survivorPrefab;
    public GameObject killerPrefab;
    public Transform[] survivorSpawns;
    public Transform[] killerSpawns;
    void Start(){ if(PhotonNetwork.InRoom) SpawnRoles(); }
    void SpawnRoles(){ int players=PhotonNetwork.CurrentRoom.PlayerCount; if(players==1) PhotonNetwork.Instantiate(killerPrefab.name,killerSpawns[0].position,Quaternion.identity); else PhotonNetwork.Instantiate(survivorPrefab.name,survivorSpawns[players%survivorSpawns.Length].position,Quaternion.identity); }
}
