using UnityEngine;
using Photon.Pun;
public class PlayerController : MonoBehaviourPun {
    public float moveSpeed=4f; private float stunTimer=0f; CharacterController cc;
    void Awake(){ cc=GetComponent<CharacterController>(); if(!photonView.IsMine) foreach(var c in GetComponentsInChildren<Camera>()) c.enabled=false; }
    void Update(){ if(!photonView.IsMine) return; if(stunTimer>0){ stunTimer-=Time.deltaTime; return;} float h=Input.GetAxis("Horizontal"); float v=Input.GetAxis("Vertical"); Vector3 dir=new Vector3(h,0,v); if(dir.sqrMagnitude>0.01f){ cc.SimpleMove(dir.normalized*moveSpeed); transform.forward=dir.normalized; } if(Input.GetKeyDown(KeyCode.E)) Debug.Log("Interact"); }
    public void Stun(float t){ stunTimer=t; Debug.Log("Stunned for "+t); }
}
