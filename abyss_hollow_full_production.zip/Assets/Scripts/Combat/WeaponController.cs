using UnityEngine;
using Photon.Pun;
public class WeaponController : MonoBehaviourPun {
    public int durability=3; public float stun=1f; public LayerMask hitMask;
    void Update(){ if(!photonView.IsMine) return; if(Input.GetMouseButtonDown(0)) Attack(); }
    void Attack(){ RaycastHit hit; if(Physics.Raycast(transform.position+Vector3.up*0.5f, transform.forward, out hit, 2f, hitMask)){ var pc=hit.collider.GetComponent<PlayerController>(); if(pc!=null) photonView.RPC("RPC_Stun", RpcTarget.All, pc.photonView.ViewID, stun); durability--; if(durability<=0) Destroy(gameObject); } }
    [PunRPC] void RPC_Stun(int viewId, float t){ PhotonView pv=PhotonView.Find(viewId); if(pv!=null){ var pc=pv.GetComponent<PlayerController>(); if(pc!=null) pc.Stun(t);} }
}
