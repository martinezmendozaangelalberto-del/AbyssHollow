using UnityEngine;
using Photon.Pun;
public class KillerController : MonoBehaviourPun {
    public float moveSpeed=5f; public float leapCooldown=15f; private float lastLeap=-99f; private float stunTimer=0f;
    void Awake(){ if(!photonView.IsMine) foreach(var c in GetComponentsInChildren<Camera>()) c.enabled=false; }
    void Update(){ if(!photonView.IsMine) return; if(stunTimer>0){ stunTimer-=Time.deltaTime; return;} float h=Input.GetAxis("Horizontal"); float v=Input.GetAxis("Vertical"); Vector3 dir=new Vector3(h,0,v); if(dir.sqrMagnitude>0.01f) transform.position+=dir.normalized*moveSpeed*Time.deltaTime; if(Input.GetKeyDown(KeyCode.Space) && Time.time-lastLeap>leapCooldown){ DoLeap(); lastLeap=Time.time; } }
    public void Stun(float t){ stunTimer=t; Debug.Log("Killer stunned for "+t); }
    void DoLeap(){ Debug.Log("Killer leap"); }
}
