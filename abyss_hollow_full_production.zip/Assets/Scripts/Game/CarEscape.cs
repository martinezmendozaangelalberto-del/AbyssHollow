using UnityEngine;
using Photon.Pun;
public class CarEscape : MonoBehaviourPun {
    public bool hasFuel=false, hasKeys=false, powered=false;
    public void AddPart(string part){ if(part=="Fuel") hasFuel=true; if(part=="Keys") hasKeys=true; if(part=="Battery") powered=true; }
    public bool TryStartEngine(){ if(hasFuel && hasKeys && powered){ photonView.RPC("RPC_EngineStarted", RpcTarget.All); return true; } return false; }
    [PunRPC] void RPC_EngineStarted(){ Debug.Log("Engine started - escape!"); }
}
