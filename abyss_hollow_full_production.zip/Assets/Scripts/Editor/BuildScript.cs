using UnityEditor;
using UnityEngine;
public class BuildScript {
    public static void PerformAndroidBuild() {
        string[] scenes = { "Assets/Scenes/MainMenu.unity" , "Assets/Scenes/DemoScene.unity" };
        string path = "Builds/AbyssHollow.apk";
        BuildPipeline.BuildPlayer(scenes, path, BuildTarget.Android, BuildOptions.None);
        Debug.Log("Build finished: " + path);
    }
}
