using UnityEngine;
using Photon.Pun;
public class PhotonNetworkManager : MonoBehaviourPunCallbacks {
    public void Start(){ PhotonNetwork.ConnectUsingSettings(); }
    public override void OnConnectedToMaster(){ PhotonNetwork.AutomaticallySyncScene=true; Debug.Log("Photon Connected"); }
}
